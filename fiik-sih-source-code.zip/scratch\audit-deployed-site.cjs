const https = require('https');

function fetchUrl(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.on('data', (chunk) => (data += chunk));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    }).on('error', reject);
  });
}

async function runAudit() {
  console.log('=== STARTING DEPLOYED WEBSITE AUDIT ===\n');
  const baseUrl = 'https://sriram123806.github.io/fiik-sih-2026/';
  
  // 1. Root index.html check
  console.log('1. Checking root URL:', baseUrl);
  const rootRes = await fetchUrl(baseUrl);
  console.log('   Root HTML Status:', rootRes.status, rootRes.status === 200 ? '✅ PASS' : '❌ FAIL');
  
  // 2. Extract script and css assets
  const scriptMatch = rootRes.body.match(/src="([^"]+)"/g) || [];
  const cssMatch = rootRes.body.match(/href="([^"]+\.css)"/g) || [];
  
  console.log('\n2. Auditing bundled static assets:');
  for (const s of scriptMatch) {
    const assetPath = s.replace('src="', '').replace('"', '').replace('./', '');
    const fullUrl = baseUrl + assetPath;
    const res = await fetchUrl(fullUrl);
    console.log(`   Script asset: ${assetPath} -> Status: ${res.status} ${res.status === 200 ? '✅ PASS' : '❌ FAIL'}`);
  }
  
  for (const c of cssMatch) {
    const assetPath = c.replace('href="', '').replace('"', '').replace('./', '');
    const fullUrl = baseUrl + assetPath;
    const res = await fetchUrl(fullUrl);
    console.log(`   CSS asset: ${assetPath} -> Status: ${res.status} ${res.status === 200 ? '✅ PASS' : '❌ FAIL'}`);
  }

  // 3. Hero image asset check
  console.log('\n3. Auditing Hero Image Asset:');
  const heroUrl = baseUrl + 'assets/india-govt-hero-2C44VCkb.png';
  const heroRes = await fetchUrl(heroUrl);
  console.log(`   Hero Image: assets/india-govt-hero-2C44VCkb.png -> Status: ${heroRes.status}, Content-Type: ${heroRes.headers['content-type']}, Content-Length: ${heroRes.headers['content-length']} bytes ${heroRes.status === 200 ? '✅ PASS' : '❌ FAIL'}`);

  console.log('\n=== AUDIT COMPLETE ===');
}

runAudit().catch((err) => console.error('Audit Error:', err));
