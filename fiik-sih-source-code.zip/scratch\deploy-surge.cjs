const { spawn } = require('child_process');
const path = require('path');

const email = 'fiik.sih.demo.2026@gmail.com';
const pass = 'FIIK_SIH_2026_demo!';
const distPath = path.resolve(__dirname, '../dist');
const domain = 'fiik-sih-2026.surge.sh';

console.log('Starting Surge deployment to', domain);

const child = spawn('npx.cmd', ['surge', distPath, domain], {
  stdio: ['pipe', 'pipe', 'pipe'],
  shell: true,
});

child.stdout.on('data', (data) => {
  const str = data.toString();
  console.log('[STDOUT]', str);

  if (str.includes('email:')) {
    console.log('Writing email...');
    child.stdin.write(email + '\n');
  }
  if (str.includes('password:')) {
    console.log('Writing password...');
    child.stdin.write(pass + '\n');
  }
  if (str.includes('project:') || str.includes('path:')) {
    child.stdin.write('\n');
  }
  if (str.includes('domain:')) {
    child.stdin.write(domain + '\n');
  }
});

child.stderr.on('data', (data) => {
  console.error('[STDERR]', data.toString());
});

child.on('close', (code) => {
  console.log('Surge process exited with code:', code);
});
